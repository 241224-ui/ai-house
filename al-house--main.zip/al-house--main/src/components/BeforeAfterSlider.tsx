import { useState, useRef, useEffect, MouseEvent as ReactMouseEvent, TouchEvent as ReactTouchEvent } from "react";
import { Sliders, Maximize2, Minimize2, ZoomIn, ZoomOut, Eye, EyeOff, LayoutGrid } from "lucide-react";

interface BeforeAfterSliderProps {
  originalUrl: string;
  redesignedUrl: string;
  originalLabel?: string;
  redesignedLabel?: string;
}

export default function BeforeAfterSlider({
  originalUrl,
  redesignedUrl,
  originalLabel = "BEFORE (Original)",
  redesignedLabel = "AFTER (AI Redesign)",
}: BeforeAfterSliderProps) {
  const [sliderPosition, setSliderPosition] = useState(50); // percentage 0 - 100
  const [isDragging, setIsDragging] = useState(false);
  const [isSideBySide, setIsSideBySide] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(1.0); // 1.0 to 2.5
  const containerRef = useRef<HTMLDivElement>(null);

  // Handle Dragging
  const handleMove = (clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPosition(percentage);
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging) return;
    handleMove(e.clientX);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleTouchMove = (e: TouchEvent) => {
    if (!isDragging) return;
    if (e.touches.length > 0) {
      handleMove(e.touches[0].clientX);
    }
  };

  useEffect(() => {
    if (isDragging) {
      window.addEventListener("mousemove", handleMouseMove);
      window.addEventListener("mouseup", handleMouseUp);
      window.addEventListener("touchmove", handleTouchMove, { passive: true });
      window.addEventListener("touchend", handleMouseUp);
    }

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
      window.removeEventListener("touchmove", handleTouchMove);
      window.removeEventListener("touchend", handleMouseUp);
    };
  }, [isDragging]);

  const handleMouseDown = (e: ReactMouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleTouchStart = () => {
    setIsDragging(true);
  };

  const resetZoom = () => setZoomLevel(1.0);

  return (
    <div
      id="before-after-module"
      className={`relative w-full flex flex-col gap-4 ${
        isFullscreen
          ? "fixed inset-0 z-50 bg-slate-950 p-6 flex flex-col justify-between"
          : ""
      }`}
    >
      {/* Top Header controls */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300 shadow-md">
          <Sliders className="w-4 h-4 text-indigo-400" />
          <span>COMPARISON SYSTEM</span>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Side by side / Slider toggle */}
          <button
            id="btn-comparison-mode"
            onClick={() => {
              setIsSideBySide(!isSideBySide);
              resetZoom();
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-medium transition-all duration-300 ${
              isSideBySide
                ? "bg-indigo-600/90 border-indigo-500 text-white shadow-lg"
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>{isSideBySide ? "Split Mode" : "Side-by-Side"}</span>
          </button>

          {/* Zoom In */}
          <div className="flex items-center gap-1 px-2 py-1 rounded-xl bg-slate-900 border border-slate-800 text-slate-400">
            <button
              id="btn-zoom-out"
              onClick={() => setZoomLevel(prev => Math.max(1.0, prev - 0.25))}
              disabled={zoomLevel <= 1.0}
              className="p-1 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400 transition"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[10px] font-mono px-1 select-none">
              {Math.round(zoomLevel * 100)}%
            </span>
            <button
              id="btn-zoom-in"
              onClick={() => setZoomLevel(prev => Math.min(2.5, prev + 0.25))}
              disabled={zoomLevel >= 2.5}
              className="p-1 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400 transition"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Fullscreen Toggle */}
          <button
            id="btn-fullscreen-compare"
            onClick={() => {
              setIsFullscreen(!isFullscreen);
              resetZoom();
            }}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-medium text-slate-300 hover:text-white transition shadow-sm"
          >
            {isFullscreen ? (
              <>
                <Minimize2 className="w-3.5 h-3.5" />
                <span>Exit Fullscreen</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-3.5 h-3.5" />
                <span>Fullscreen</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Display Frame */}
      <div
        ref={containerRef}
        id="slider-view-wrapper"
        className={`relative w-full rounded-3xl overflow-hidden border border-slate-800/80 bg-slate-950/40 select-none ${
          isFullscreen ? "flex-1 my-4 h-0" : "h-[360px] md:h-[480px]"
        }`}
      >
        {isSideBySide ? (
          /* Side-by-side Layout */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-3 w-full h-full">
            {/* Before */}
            <div className="relative rounded-2xl overflow-hidden border border-slate-900 bg-slate-950">
              <img
                src={originalUrl}
                alt="Original design"
                className="w-full h-full object-cover transition-transform duration-300"
                style={{ transform: `scale(${zoomLevel})` }}
                referrerPolicy="no-referrer"
              />
              <span className="absolute bottom-3 left-3 px-3 py-1 rounded-lg bg-black/70 backdrop-blur-md text-[10px] font-mono tracking-wider text-slate-300 border border-slate-800">
                {originalLabel}
              </span>
            </div>

            {/* After */}
            <div className="relative rounded-2xl overflow-hidden border border-slate-900 bg-slate-950">
              <img
                src={redesignedUrl}
                alt="AI Redesigned design"
                className="w-full h-full object-cover transition-transform duration-300"
                style={{ transform: `scale(${zoomLevel})` }}
                referrerPolicy="no-referrer"
              />
              <span className="absolute bottom-3 right-3 px-3 py-1 rounded-lg bg-indigo-950/80 backdrop-blur-md text-[10px] font-mono tracking-wider text-indigo-300 border border-indigo-900">
                {redesignedLabel}
              </span>
            </div>
          </div>
        ) : (
          /* Drag Slider Layout */
          <div className="relative w-full h-full overflow-hidden">
            {/* Original Image (Before) - Base layer */}
            <div className="absolute inset-0 w-full h-full">
              <img
                src={originalUrl}
                alt="Original"
                className="absolute inset-0 w-full h-full object-cover"
                style={{
                  transform: `scale(${zoomLevel})`,
                  pointerEvents: "none",
                }}
                referrerPolicy="no-referrer"
              />
              <span className="absolute bottom-4 left-4 z-10 px-3 py-1 rounded-lg bg-black/65 backdrop-blur-md text-[10px] font-mono tracking-wider text-slate-300 border border-slate-800">
                {originalLabel}
              </span>
            </div>

            {/* Redesigned Image (After) - Clipped Overlay layer */}
            <div
              className="absolute inset-y-0 left-0 h-full overflow-hidden"
              style={{ width: `${sliderPosition}%` }}
            >
              {/* Ensure image remains same dimensions even inside clipped container */}
              <div
                className="absolute top-0 left-0 w-full h-full"
                style={{ width: containerRef.current?.clientWidth || "100%" }}
              >
                <img
                  src={redesignedUrl}
                  alt="Redesigned"
                  className="absolute inset-0 w-full h-full object-cover"
                  style={{
                    transform: `scale(${zoomLevel})`,
                    pointerEvents: "none",
                    width: containerRef.current?.clientWidth || "100%",
                    height: containerRef.current?.clientHeight || "100%",
                  }}
                  referrerPolicy="no-referrer"
                />
              </div>
              <span className="absolute bottom-4 left-4 z-10 px-3 py-1 rounded-lg bg-indigo-950/80 backdrop-blur-md text-[10px] font-mono tracking-wider text-indigo-300 border border-indigo-900 whitespace-nowrap">
                {redesignedLabel}
              </span>
            </div>

            {/* Vertical Sliding Separator Line */}
            <div
              className="absolute inset-y-0 z-20 w-[2px] bg-indigo-500 cursor-ew-resize group"
              style={{ left: `${sliderPosition}%` }}
              onMouseDown={handleMouseDown}
              onTouchStart={handleTouchStart}
            >
              {/* Central handle bubble */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center w-9 h-9 rounded-full bg-slate-900 border-2 border-indigo-500 text-white shadow-xl hover:scale-110 active:scale-95 transition-all duration-200">
                <Sliders className="w-4 h-4 rotate-90 text-indigo-400 group-hover:text-indigo-300" />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Helper Guidance Legend */}
      {!isSideBySide && (
        <div className="text-center text-[11px] font-mono text-slate-500">
          ◀ Slide or drag the handle to inspect details before and after redesign ▶
        </div>
      )}
    </div>
  );
}
