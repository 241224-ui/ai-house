import { useState, useRef, DragEvent, ChangeEvent, MouseEvent } from "react";
import { UploadCloud, Image as ImageIcon, X, AlertTriangle, CheckCircle2 } from "lucide-react";

interface UploadAreaProps {
  onImageSelected: (base64Image: string, mimeType: string) => void;
  onClear: () => void;
}

export default function UploadArea({ onImageSelected, onClear }: UploadAreaProps) {
  const [dragActive, setDragActive] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [uploadState, setUploadState] = useState<'idle' | 'progressing' | 'completed' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Validate and handle file input
  const processFile = (file: File) => {
    const validTypes = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
    if (!validTypes.includes(file.type)) {
      setUploadState('error');
      setErrorMessage("Unsupported file format. Please upload JPG, JPEG, PNG, or WebP.");
      return;
    }

    // Limit file size to 8MB for stable processing
    if (file.size > 8 * 1024 * 1024) {
      setUploadState('error');
      setErrorMessage("File exceeds 8MB. Please upload a smaller image.");
      return;
    }

    setUploadState('progressing');
    setErrorMessage(null);
    setProgress(15);

    // Simulate standard fast secure local processing progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          
          // Read file as base64 on complete
          const reader = new FileReader();
          reader.onloadend = () => {
            const resultBase64 = reader.result as string;
            setImagePreview(resultBase64);
            onImageSelected(resultBase64, file.type);
            setUploadState('completed');
          };
          reader.readAsDataURL(file);

          return 100;
        }
        return prev + 17;
      });
    }, 120);
  };

  // Drag listeners
  const handleDrag = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const onButtonClick = () => {
    fileInputRef.current?.click();
  };

  const handleRemove = (e: MouseEvent) => {
    e.stopPropagation();
    setImagePreview(null);
    setUploadState('idle');
    setProgress(0);
    onClear();
  };

  return (
    <div id="upload-panel-parent" className="w-full">
      <input
        ref={fileInputRef}
        type="file"
        id="input-file-upload"
        className="hidden"
        multiple={false}
        accept=".jpg,.jpeg,.png,.webp"
        onChange={handleChange}
      />

      {uploadState === 'idle' || uploadState === 'error' ? (
        /* Dropzone view */
        <div
          id="dropzone-area"
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
          onClick={onButtonClick}
          className={`relative group flex flex-col items-center justify-center w-full h-[220px] rounded-3xl border-2 border-dashed cursor-pointer transition-all duration-300 backdrop-blur-md ${
            dragActive
              ? "border-indigo-500 bg-indigo-500/10 scale-[1.01]"
              : "border-slate-800 bg-slate-950/40 hover:border-slate-700 hover:bg-slate-900/30"
          }`}
        >
          <div className="flex flex-col items-center justify-center p-6 text-center">
            <div className="flex items-center justify-center w-12 h-12 mb-4 rounded-2xl bg-indigo-500/10 text-indigo-400 group-hover:scale-110 group-hover:bg-indigo-500/20 transition-all duration-300">
              <UploadCloud className="w-6 h-6" />
            </div>
            
            <p className="text-sm font-medium text-slate-200">
              <span className="text-indigo-400 font-semibold">Click to upload</span> or drag and drop
            </p>
            <p className="text-xs text-slate-500 mt-1.5 font-mono">
              Supports JPEG, PNG, WebP up to 8MB
            </p>

            {uploadState === 'error' && errorMessage && (
              <div className="mt-4 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-mono">
                <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}
          </div>
        </div>
      ) : uploadState === 'progressing' ? (
        /* Uploading progress view */
        <div className="flex flex-col items-center justify-center w-full h-[220px] rounded-3xl border border-slate-800 bg-slate-950/60 backdrop-blur-md p-6">
          <div className="w-full max-w-xs flex flex-col gap-3">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-indigo-400 animate-pulse">INGESTING STRUCTURE...</span>
              <span className="text-slate-400">{progress}%</span>
            </div>
            
            {/* Progress bar container */}
            <div className="w-full h-2 rounded-full bg-slate-900 overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full transition-all duration-200"
                style={{ width: `${progress}%` }}
              />
            </div>
            
            <span className="text-[10px] text-center text-slate-500 font-mono">
              Validating architectural boundaries • Parsing mesh
            </span>
          </div>
        </div>
      ) : (
        /* Completed Preview Card */
        <div className="relative w-full rounded-3xl overflow-hidden border border-slate-800 bg-slate-950/80 shadow-xl group">
          <img
            src={imagePreview || ""}
            alt="Source Preview"
            className="w-full h-[220px] object-cover"
            referrerPolicy="no-referrer"
          />

          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-black/40 pointer-events-none" />

          {/* Floating HUD info */}
          <div className="absolute bottom-4 left-4 flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-mono backdrop-blur-sm">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>SOURCE CAPTURED</span>
            </div>
          </div>

          {/* Action button to remove */}
          <button
            id="btn-remove-source"
            onClick={handleRemove}
            className="absolute top-4 right-4 flex items-center justify-center w-8 h-8 rounded-full bg-black/75 hover:bg-rose-600 border border-slate-800 hover:border-rose-500 text-slate-400 hover:text-white transition-all duration-300 shadow-md"
            title="Clear and Upload Another"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}
