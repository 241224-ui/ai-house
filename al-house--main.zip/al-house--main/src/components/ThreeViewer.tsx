import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { RedesignControls } from "../types";
import { Sun, Moon, Sparkles, RefreshCw } from "lucide-react";

interface ThreeViewerProps {
  controls: RedesignControls;
}

export default function ThreeViewer({ controls }: ThreeViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isNight, setIsNight] = useState(false);
  const [isOrbiting, setIsOrbiting] = useState(true);

  // Use refs to store ThreeJS instances for real-time updates
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const houseGroupRef = useRef<THREE.Group | null>(null);
  const lightsGroupRef = useRef<THREE.Group | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);

  // Toggle Day/Night
  const toggleTimeOfDay = () => {
    setIsNight((prev) => !prev);
  };

  useEffect(() => {
    if (!containerRef.current) return;

    const width = containerRef.current.clientWidth || 600;
    const height = containerRef.current.clientHeight || 450;

    // 1. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(12, 8, 12);
    cameraRef.current = camera;

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 4. Controls
    const orbitControls = new OrbitControls(camera, renderer.domElement);
    orbitControls.enableDamping = true;
    orbitControls.dampingFactor = 0.05;
    orbitControls.maxPolarAngle = Math.PI / 2 - 0.05; // Don't go below ground
    orbitControls.minDistance = 5;
    orbitControls.maxDistance = 25;
    controlsRef.current = orbitControls;

    // 5. Sky / Environment
    const skyGeo = new THREE.SphereGeometry(40, 32, 15);
    const skyMat = new THREE.MeshBasicMaterial({
      side: THREE.BackSide,
      color: 0x1a2639, // Default day/dusk background
    });
    const sky = new THREE.Mesh(skyGeo, skyMat);
    scene.add(sky);

    // 6. Ground
    const groundGeo = new THREE.PlaneGeometry(30, 30);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x2d3a22, // Lush lawn grass
      roughness: 0.9,
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Grid helper for a sleek designer workspace feeling
    const gridHelper = new THREE.GridHelper(30, 30, 0x4f46e5, 0x312e81);
    gridHelper.position.y = 0.01;
    (gridHelper.material as THREE.Material).opacity = 0.2;
    (gridHelper.material as THREE.Material).transparent = true;
    scene.add(gridHelper);

    // 7. House & Lights Groups
    const houseGroup = new THREE.Group();
    scene.add(houseGroup);
    houseGroupRef.current = houseGroup;

    const lightsGroup = new THREE.Group();
    scene.add(lightsGroup);
    lightsGroupRef.current = lightsGroup;

    // 8. Setup Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    lightsGroup.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(10, 15, 10);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    dirLight.shadow.bias = -0.001;
    lightsGroup.add(dirLight);

    // Point lights for Night glow
    const nightLight1 = new THREE.PointLight(0xffaa44, 1.5, 8);
    nightLight1.position.set(0, 3, 2);
    lightsGroup.add(nightLight1);

    const nightLight2 = new THREE.PointLight(0x00aaff, 1.5, 8);
    nightLight2.position.set(-2, 1.5, -2);
    lightsGroup.add(nightLight2);

    // 9. Resize Handler
    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      const { width: w, height: h } = entries[0].contentRect;
      if (rendererRef.current && cameraRef.current) {
        cameraRef.current.aspect = w / h;
        cameraRef.current.updateProjectionMatrix();
        rendererRef.current.setSize(w, h);
      }
    });
    resizeObserver.observe(containerRef.current);

    // 10. Animation loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      if (orbitControls && isOrbiting) {
        // Auto rotate slowly
        orbitControls.autoRotate = isOrbiting;
        orbitControls.autoRotateSpeed = 0.4;
      }

      orbitControls.update();

      // Slow dynamic features (like water rippling, foliage swaying slightly)
      const elapsedTime = clock.getElapsedTime();
      const water = houseGroup.getObjectByName("water");
      if (water) {
        (water as THREE.Mesh).position.y = -0.01 + Math.sin(elapsedTime * 2) * 0.015;
      }

      // Pulse smart neon lights
      const smartLights = houseGroup.getObjectByName("smartGlow");
      if (smartLights) {
        const material = (smartLights as THREE.Mesh).material as THREE.MeshBasicMaterial;
        material.color.setHSL(0.55 + Math.sin(elapsedTime * 3) * 0.05, 1.0, 0.6);
      }

      renderer.render(scene, camera);
    };
    animate();

    // Clean up
    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      orbitControls.dispose();
      renderer.dispose();
      if (containerRef.current && renderer.domElement) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Update Scene elements based on Controls and isNight
  useEffect(() => {
    const scene = sceneRef.current;
    const houseGroup = houseGroupRef.current;
    const lightsGroup = lightsGroupRef.current;
    if (!scene || !houseGroup || !lightsGroup) return;

    // Clear previous house group mesh contents to redraw procedurally
    while (houseGroup.children.length > 0) {
      const child = houseGroup.children[0];
      houseGroup.remove(child);
    }

    // Dynamic scale/proportions based on modern level and luxury level
    const mScale = 0.8 + (controls.modernLevel / 100) * 0.5;
    const luxuryCoeff = controls.luxuryLevel / 100;

    // Resolve materials colors
    const paintColorHex = controls.paintColor === "Charcoal Grey" ? 0x22252a
                         : controls.paintColor === "Warm Beige" ? 0xd2b48c
                         : controls.paintColor === "Snow White" ? 0xf5f5f5
                         : controls.paintColor === "Terracotta" ? 0xc26a4f
                         : 0xdddddd;

    const wallColor = paintColorHex;

    // Concrete & Wood wood planks or Stone/Glass dark accents
    let trimMaterial: THREE.MeshStandardMaterial;
    if (controls.wallMaterial === "Concrete & Wood") {
      trimMaterial = new THREE.MeshStandardMaterial({ color: 0x8b5a2b, roughness: 0.6 }); // Wood
    } else if (controls.wallMaterial === "Stone & Glass") {
      trimMaterial = new THREE.MeshStandardMaterial({ color: 0x444444, roughness: 0.3, metalness: 0.5 }); // Stone slate
    } else {
      trimMaterial = new THREE.MeshStandardMaterial({ color: 0xefefef, roughness: 0.8 }); // Smooth white
    }

    // 1. Ground Slab (Platform base)
    const platformGeo = new THREE.BoxGeometry(7, 0.15, 6);
    const platformMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.4 });
    const platform = new THREE.Mesh(platformGeo, platformMat);
    platform.position.y = 0.075;
    platform.receiveShadow = true;
    platform.castShadow = true;
    houseGroup.add(platform);

    // 2. Main Floor Box
    const mainBoxGeo = new THREE.BoxGeometry(5 * mScale, 2, 4);
    const mainBoxMat = new THREE.MeshStandardMaterial({
      color: wallColor,
      roughness: 0.5,
      metalness: 0.1,
    });
    const mainBox = new THREE.Mesh(mainBoxGeo, mainBoxMat);
    mainBox.position.set(0, 1.15, 0);
    mainBox.castShadow = true;
    mainBox.receiveShadow = true;
    houseGroup.add(mainBox);

    // Wood or Stone Accent Panel
    const accentPanelGeo = new THREE.BoxGeometry(0.1, 2, 1.8);
    const accentPanel = new THREE.Mesh(accentPanelGeo, trimMaterial);
    accentPanel.position.set((2.5 * mScale) + 0.05, 1.15, 0.5);
    accentPanel.castShadow = true;
    houseGroup.add(accentPanel);

    // Second Floor Box (Cantilevered style for Modern Level)
    const upperOffset = (controls.modernLevel / 100) * 0.8;
    const upperBoxGeo = new THREE.BoxGeometry(4.5 * mScale, 1.8, 3.8);
    const upperBoxMat = new THREE.MeshStandardMaterial({
      color: 0x111827, // Dark premium contrast
      roughness: 0.3,
      metalness: 0.6,
    });
    const upperBox = new THREE.Mesh(upperBoxGeo, upperBoxMat);
    // Cantilever shifts forward/sideways depending on modern level
    upperBox.position.set(-upperOffset, 3.05, 0.2);
    upperBox.castShadow = true;
    upperBox.receiveShadow = true;
    houseGroup.add(upperBox);

    // 3. Roof Structures based on Roof Style selection
    if (controls.roofStyle === "Flat Minimal") {
      const roofGeo = new THREE.BoxGeometry(4.8 * mScale, 0.15, 4);
      const roofMat = new THREE.MeshStandardMaterial({ color: 0x374151, roughness: 0.5 });
      const roof = new THREE.Mesh(roofGeo, roofMat);
      roof.position.set(-upperOffset, 4.025, 0.2);
      roof.castShadow = true;
      houseGroup.add(roof);
    } else if (controls.roofStyle === "Sloped Modern") {
      // Dynamic single-slope roof
      const roofGeo = new THREE.BoxGeometry(5.2 * mScale, 0.1, 4.2);
      const roofMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.3, metalness: 0.8 });
      const roof = new THREE.Mesh(roofGeo, roofMat);
      roof.position.set(-upperOffset, 4.2, 0.2);
      roof.rotation.z = -0.15; // Sloped
      roof.castShadow = true;
      houseGroup.add(roof);
    } else {
      // Glass Canopy
      const frameGeo = new THREE.BoxGeometry(5 * mScale, 0.15, 4);
      const frameMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.2 });
      const frame = new THREE.Mesh(frameGeo, frameMat);
      frame.position.set(-upperOffset, 4.025, 0.2);
      houseGroup.add(frame);

      const glassGeo = new THREE.BoxGeometry(4.6 * mScale, 0.05, 3.6);
      const glassMat = new THREE.MeshPhysicalMaterial({
        color: 0x00ffff,
        transparent: true,
        opacity: 0.6,
        roughness: 0.1,
        transmission: 0.9,
      });
      const glass = new THREE.Mesh(glassGeo, glassMat);
      glass.position.set(-upperOffset, 4.075, 0.2);
      houseGroup.add(glass);
    }

    // 4. Windows based on Window Size selection
    const glassColor = isNight ? 0xffaa00 : 0x88ccff; // Glow golden at night
    const windowMat = new THREE.MeshStandardMaterial({
      color: glassColor,
      roughness: 0.1,
      metalness: 0.9,
      emissive: isNight ? 0xffaa44 : 0x112233,
      emissiveIntensity: isNight ? 1.5 : 0.2,
    });

    if (controls.windowSize === "Floor-to-Ceiling") {
      // Huge windows front ground floor
      const windowGeo = new THREE.BoxGeometry(0.05, 1.6, 2.5);
      const win = new THREE.Mesh(windowGeo, windowMat);
      win.position.set((2.5 * mScale) - 0.02, 1.15, -0.5);
      houseGroup.add(win);

      // Huge upper floor window
      const upperWinGeo = new THREE.BoxGeometry(3 * mScale, 1.2, 0.05);
      const upperWin = new THREE.Mesh(upperWinGeo, windowMat);
      upperWin.position.set(-upperOffset, 3.05, 2.1);
      houseGroup.add(upperWin);
    } else if (controls.windowSize === "Panoramic") {
      // Wide horizontal strips
      const windowGeo = new THREE.BoxGeometry(0.05, 0.6, 3.2);
      const win = new THREE.Mesh(windowGeo, windowMat);
      win.position.set((2.5 * mScale) - 0.02, 1.25, -0.2);
      houseGroup.add(win);

      const upperWinGeo = new THREE.BoxGeometry(3.5 * mScale, 0.5, 0.05);
      const upperWin = new THREE.Mesh(upperWinGeo, windowMat);
      upperWin.position.set(-upperOffset, 3.15, 2.1);
      houseGroup.add(upperWin);
    } else {
      // Standard Minimal
      const windowGeo = new THREE.BoxGeometry(0.05, 1.0, 1.2);
      const win1 = new THREE.Mesh(windowGeo, windowMat);
      win1.position.set((2.5 * mScale) - 0.02, 1.2, -0.8);
      houseGroup.add(win1);

      const win2 = new THREE.Mesh(windowGeo, windowMat);
      win2.position.set((2.5 * mScale) - 0.02, 1.2, 0.8);
      houseGroup.add(win2);
    }

    // 5. Custom features: Balcony
    if (controls.balcony) {
      // Premium balcony deck cantilevered out from second floor
      const balconyGeo = new THREE.BoxGeometry(2.5 * mScale, 0.1, 1.5);
      const balcony = new THREE.Mesh(balconyGeo, trimMaterial);
      balcony.position.set(-upperOffset, 2.05, 2.85);
      balcony.castShadow = true;
      houseGroup.add(balcony);

      // Railings (glass panels)
      const railGeo = new THREE.BoxGeometry(2.4 * mScale, 0.4, 0.05);
      const railMat = new THREE.MeshPhysicalMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.4,
        roughness: 0.1,
      });
      const rail = new THREE.Mesh(railGeo, railMat);
      rail.position.set(-upperOffset, 2.3, 3.55);
      houseGroup.add(rail);
    }

    // 6. Custom features: Swimming Pool
    if (controls.swimmingPool) {
      // Cut out pool deck
      const poolDeckGeo = new THREE.BoxGeometry(3.5, 0.02, 2.2);
      const poolDeckMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.5 });
      const poolDeck = new THREE.Mesh(poolDeckGeo, poolDeckMat);
      poolDeck.position.set(2, 0.155, 2.2);
      houseGroup.add(poolDeck);

      // Water mesh that animates dynamically
      const waterGeo = new THREE.BoxGeometry(3.2, 0.02, 1.9);
      const waterMat = new THREE.MeshPhysicalMaterial({
        color: 0x00f0ff,
        transparent: true,
        opacity: 0.7,
        roughness: 0.1,
        metalness: 0.1,
        transmission: 0.8,
        ior: 1.33,
      });
      const water = new THREE.Mesh(waterGeo, waterMat);
      water.name = "water";
      water.position.set(2, 0.16, 2.2);
      houseGroup.add(water);

      // Sun loungers next to pool
      const loungerGeo = new THREE.BoxGeometry(1.2, 0.1, 0.5);
      const loungerMat = new THREE.MeshStandardMaterial({ color: 0xfbfbfb });
      const lounger = new THREE.Mesh(loungerGeo, loungerMat);
      lounger.position.set(2.4, 0.22, 1.0);
      lounger.rotation.y = 0.2;
      houseGroup.add(lounger);
    }

    // 7. Custom features: Solar Panels
    if (controls.solarPanels) {
      const panelMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.1, metalness: 0.9 });
      const panelGeo = new THREE.BoxGeometry(1.2, 0.03, 1.6);

      const panel1 = new THREE.Mesh(panelGeo, panelMat);
      panel1.position.set(-upperOffset - 1, 4.12, 0.2);
      panel1.rotation.x = -0.1; // slight slant
      houseGroup.add(panel1);

      const panel2 = new THREE.Mesh(panelGeo, panelMat);
      panel2.position.set(-upperOffset + 1, 4.12, 0.2);
      panel2.rotation.x = -0.1;
      houseGroup.add(panel2);
    }

    // 8. Custom features: Garage
    if (controls.garage) {
      const garageBoxGeo = new THREE.BoxGeometry(2, 1.4, 2);
      const garageBoxMat = new THREE.MeshStandardMaterial({ color: wallColor });
      const garageBox = new THREE.Mesh(garageBoxGeo, garageBoxMat);
      garageBox.position.set(-2.8 * mScale, 0.85, -1);
      garageBox.castShadow = true;
      houseGroup.add(garageBox);

      // Garage Frosted Glass Door
      const doorGeo = new THREE.BoxGeometry(1.8, 1.2, 0.05);
      const doorMat = new THREE.MeshPhysicalMaterial({
        color: 0xcceeff,
        transparent: true,
        opacity: 0.7,
        roughness: 0.5,
      });
      const door = new THREE.Mesh(doorGeo, doorMat);
      door.position.set(-2.8 * mScale, 0.75, 0.02);
      houseGroup.add(door);
    }

    // 9. Custom features: Garden (Landscaped minimal details)
    if (controls.garden) {
      // Add a couple of minimalist trees (cylinder + cone/sphere)
      const treeTrunkGeo = new THREE.CylinderGeometry(0.1, 0.1, 1.8, 8);
      const treeTrunkMat = new THREE.MeshStandardMaterial({ color: 0x5c4033 });

      const treeLeafGeo = new THREE.SphereGeometry(0.7, 8, 8);
      const treeLeafMat = new THREE.MeshStandardMaterial({ color: 0x1e3f20, roughness: 0.8 });

      // Tree 1
      const trunk1 = new THREE.Mesh(treeTrunkGeo, treeTrunkMat);
      trunk1.position.set(-5, 0.9, 4);
      trunk1.castShadow = true;
      houseGroup.add(trunk1);

      const leaf1 = new THREE.Mesh(treeLeafGeo, treeLeafMat);
      leaf1.position.set(-5, 1.8, 4);
      leaf1.castShadow = true;
      houseGroup.add(leaf1);

      // Tree 2
      const trunk2 = new THREE.Mesh(treeTrunkGeo, treeTrunkMat);
      trunk2.position.set(-4, 0.9, -5);
      trunk2.castShadow = true;
      houseGroup.add(trunk2);

      const leaf2 = new THREE.Mesh(treeLeafGeo, treeLeafMat);
      leaf2.position.set(-4, 1.8, -5);
      leaf2.castShadow = true;
      houseGroup.add(leaf2);

      // Pathway stones
      for (let i = 0; i < 5; i++) {
        const stoneGeo = new THREE.BoxGeometry(0.6, 0.02, 0.4);
        const stoneMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.9 });
        const stone = new THREE.Mesh(stoneGeo, stoneMat);
        stone.position.set(-0.5 - i * 0.8, 0.16, 2.5);
        houseGroup.add(stone);
      }
    }

    // 10. Smart Home LED strip accents
    if (controls.smartHomeFeatures) {
      const smartGlowGeo = new THREE.BoxGeometry(5.1 * mScale, 0.05, 0.05);
      const smartGlowMat = new THREE.MeshBasicMaterial({
        color: 0x00f3ff,
      });
      const smartGlow = new THREE.Mesh(smartGlowGeo, smartGlowMat);
      smartGlow.name = "smartGlow";
      smartGlow.position.set(0, 2.12, 2.02);
      houseGroup.add(smartGlow);

      // Dynamic path indicator glowing nodes
      const nodeGeo = new THREE.SphereGeometry(0.06, 8, 8);
      const nodeMat = new THREE.MeshBasicMaterial({ color: 0x22c55e });
      const node1 = new THREE.Mesh(nodeGeo, nodeMat);
      node1.position.set(1.5, 0.2, 4.5);
      houseGroup.add(node1);
    }

    // Adjust environment depending on Day / Night selection
    const sky = scene.children.find(child => child instanceof THREE.Mesh && child.geometry instanceof THREE.SphereGeometry) as THREE.Mesh | undefined;
    const dirLight = lightsGroup.children.find(child => child instanceof THREE.DirectionalLight) as THREE.DirectionalLight | undefined;
    const ambientLight = lightsGroup.children.find(child => child instanceof THREE.AmbientLight) as THREE.AmbientLight | undefined;
    const pointLights = lightsGroup.children.filter(child => child instanceof THREE.PointLight) as THREE.PointLight[];

    if (sky && sky.material) {
      const skyMat = sky.material as THREE.MeshBasicMaterial;
      skyMat.color.setHex(isNight ? 0x050510 : 0x1a2639);
    }

    if (isNight) {
      // Deep indigo night lighting
      scene.background = new THREE.Color(0x050510);
      if (dirLight) {
        dirLight.color.setHex(0x5c7cfa);
        dirLight.intensity = 0.15; // Soft moonlight
        dirLight.position.set(-8, 12, -8);
      }
      if (ambientLight) {
        ambientLight.color.setHex(0x0a1030);
        ambientLight.intensity = 0.5;
      }
      pointLights.forEach((pl, i) => {
        pl.visible = true;
        pl.intensity = 2.0;
      });
    } else {
      // Warm bright golden sunshine
      scene.background = new THREE.Color(0x0f172a); // Slate-900 background matching page dark mode
      if (dirLight) {
        dirLight.color.setHex(0xfffaed);
        dirLight.intensity = 1.1; // Strong sun
        dirLight.position.set(10, 15, 10);
      }
      if (ambientLight) {
        ambientLight.color.setHex(0xffffff);
        ambientLight.intensity = 0.6;
      }
      pointLights.forEach(pl => {
        pl.visible = false;
      });
    }

  }, [controls, isNight]);

  return (
    <div id="three-container-card" className="relative w-full h-[360px] md:h-[450px] rounded-3xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl">
      {/* 3D Canvas Anchor */}
      <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Floating Designer HUD */}
      <div className="absolute top-4 left-4 flex flex-col gap-2 pointer-events-none">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/90 border border-slate-800 text-[11px] font-mono tracking-wider text-indigo-400 backdrop-blur-md shadow-lg pointer-events-auto">
          <Sparkles className="w-3.5 h-3.5 animate-pulse" />
          <span>REAL-TIME 3D VIEWPORT</span>
        </div>
        <div className="flex flex-col gap-0.5 px-3 py-1.5 rounded-2xl bg-black/55 backdrop-blur-md text-[10px] text-slate-400 font-mono">
          <div>SCALE: {Math.round(80 + (controls.modernLevel / 100) * 50)}%</div>
          <div>ROOF: {controls.roofStyle.toUpperCase()}</div>
          <div>MAT: {controls.wallMaterial.toUpperCase()}</div>
        </div>
      </div>

      {/* Controls Bar */}
      <div className="absolute top-4 right-4 flex items-center gap-2">
        {/* Toggle Auto Rotation */}
        <button
          id="btn-3d-rotate"
          onClick={() => setIsOrbiting(!isOrbiting)}
          className={`flex items-center justify-center p-2.5 rounded-full border transition-all duration-300 shadow-md ${
            isOrbiting 
              ? "bg-indigo-600 border-indigo-500 text-white" 
              : "bg-slate-900/90 border-slate-800 text-slate-400 hover:text-white"
          } backdrop-blur-md`}
          title={isOrbiting ? "Disable Auto Rotation" : "Enable Auto Rotation"}
        >
          <RefreshCw className={`w-4 h-4 ${isOrbiting ? "animate-[spin_6s_linear_infinite]" : ""}`} />
        </button>

        {/* Day / Night atmospheric cycle toggle */}
        <button
          id="btn-day-night"
          onClick={toggleTimeOfDay}
          className={`flex items-center gap-2 px-4 py-2 rounded-full border transition-all duration-500 shadow-md backdrop-blur-md text-xs font-medium ${
            isNight 
              ? "bg-amber-500 border-amber-400 text-slate-950" 
              : "bg-slate-900 border-slate-800 text-amber-400 hover:text-amber-300 hover:bg-slate-800"
          }`}
        >
          {isNight ? (
            <>
              <Sun className="w-4 h-4 fill-current" />
              <span>Dusk / Day</span>
            </>
          ) : (
            <>
              <Moon className="w-4 h-4 fill-current" />
              <span>Midnight</span>
            </>
          )}
        </button>
      </div>

      {/* Touch UI Hint */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 pointer-events-none px-4 py-1.5 rounded-full bg-slate-950/80 border border-slate-800/80 text-[10px] text-slate-400 font-mono text-center backdrop-blur-sm shadow-md">
        Drag to rotate • Pinch to zoom • Right-click + drag to pan
      </div>
    </div>
  );
}
