import { RedesignControls } from "../types";
import { Sliders, Home, Sparkles, Droplets, Sun, Activity, Layers } from "lucide-react";

interface CustomizerControlsProps {
  controls: RedesignControls;
  onChange: (updated: RedesignControls) => void;
}

const PAINT_COLORS = [
  { name: "Charcoal Grey", hex: "#22252a", desc: "Sleek slate dark tone" },
  { name: "Warm Beige", hex: "#d2b48c", desc: "Organic timber warmth" },
  { name: "Snow White", hex: "#f5f5f5", desc: "Crisp architectural white" },
  { name: "Terracotta", hex: "#c26a4f", desc: "Earthy mediterranean modern" },
];

export default function CustomizerControls({ controls, onChange }: CustomizerControlsProps) {
  
  const updateControl = <K extends keyof RedesignControls>(key: K, value: RedesignControls[K]) => {
    onChange({
      ...controls,
      [key]: value,
    });
  };

  return (
    <div id="controls-panel-container" className="flex flex-col gap-6">
      
      {/* SECTION 1: Intensity metrics */}
      <div className="flex flex-col gap-4 p-5 rounded-2xl bg-slate-900/40 border border-slate-800">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 tracking-wide">
          <Activity className="w-4 h-4 text-indigo-400" />
          <span>INTENSITY ENGINE</span>
        </div>

        {/* Modern Level Slider */}
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Modernization Level</span>
            <span className="text-indigo-400 font-mono font-bold">{controls.modernLevel}%</span>
          </div>
          <input
            id="slider-modern"
            type="range"
            min="1"
            max="100"
            value={controls.modernLevel}
            onChange={(e) => updateControl("modernLevel", parseInt(e.target.value))}
            className="w-full h-1.5 rounded-full appearance-none bg-slate-800 cursor-pointer accent-indigo-500 hover:accent-indigo-400 transition"
          />
          <span className="text-[9px] text-slate-500 font-mono">
            Low (Traditional preservation) ──▶ High (Futuristic cantilevers)
          </span>
        </div>

        {/* Luxury Level Slider */}
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Luxury Factor</span>
            <span className="text-indigo-400 font-mono font-bold">{controls.luxuryLevel}%</span>
          </div>
          <input
            id="slider-luxury"
            type="range"
            min="1"
            max="100"
            value={controls.luxuryLevel}
            onChange={(e) => updateControl("luxuryLevel", parseInt(e.target.value))}
            className="w-full h-1.5 rounded-full appearance-none bg-slate-800 cursor-pointer accent-indigo-500 hover:accent-indigo-400 transition"
          />
          <span className="text-[9px] text-slate-500 font-mono">
            Low (Minimalist structure) ──▶ High (Opulent landscaping & details)
          </span>
        </div>
      </div>

      {/* SECTION 2: Architectural Details */}
      <div className="flex flex-col gap-4 p-5 rounded-2xl bg-slate-900/40 border border-slate-800">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 tracking-wide">
          <Layers className="w-4 h-4 text-indigo-400" />
          <span>ARCHITECTURAL PROFILES</span>
        </div>

        {/* Roof Style */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs text-slate-400 font-medium">Roof Style</label>
          <div className="grid grid-cols-3 gap-2">
            {(["Flat Minimal", "Sloped Modern", "Glass Canopy"] as const).map((style) => (
              <button
                key={style}
                id={`btn-roof-${style.replace(/\s+/g, "-").toLowerCase()}`}
                onClick={() => updateControl("roofStyle", style)}
                className={`px-2 py-2 rounded-xl text-[10px] font-mono tracking-tight font-medium transition-all duration-300 border ${
                  controls.roofStyle === style
                    ? "bg-indigo-600/20 border-indigo-500 text-indigo-300 shadow-md"
                    : "bg-slate-950/40 border-slate-800 text-slate-500 hover:text-slate-300 hover:border-slate-700"
                }`}
              >
                {style}
              </button>
            ))}
          </div>
        </div>

        {/* Window Profile */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs text-slate-400 font-medium">Window Framing</label>
          <div className="grid grid-cols-3 gap-2">
            {(["Floor-to-Ceiling", "Panoramic", "Standard Minimal"] as const).map((size) => (
              <button
                key={size}
                id={`btn-window-${size.replace(/\s+/g, "-").toLowerCase()}`}
                onClick={() => updateControl("windowSize", size)}
                className={`px-2 py-2 rounded-xl text-[10px] font-mono tracking-tight font-medium transition-all duration-300 border ${
                  controls.windowSize === size
                    ? "bg-indigo-600/20 border-indigo-500 text-indigo-300 shadow-md"
                    : "bg-slate-950/40 border-slate-800 text-slate-500 hover:text-slate-300 hover:border-slate-700"
                }`}
              >
                {size.split(" ")[0]}
              </button>
            ))}
          </div>
        </div>

        {/* Wall Material */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs text-slate-400 font-medium">Primary Material</label>
          <select
            id="select-material"
            value={controls.wallMaterial}
            onChange={(e) => updateControl("wallMaterial", e.target.value as any)}
            className="w-full px-3 py-2 text-xs font-mono rounded-xl bg-slate-950/80 border border-slate-800 text-slate-300 focus:outline-none focus:border-indigo-500 transition"
          >
            <option value="Concrete & Wood">Raw Concrete & Cedar Wood Planks</option>
            <option value="Stone & Glass">Polished Limestone & Black Glass</option>
            <option value="Smooth White Stucco">Smooth White Architectural Stucco</option>
          </select>
        </div>
      </div>

      {/* SECTION 3: Paint Palette */}
      <div className="flex flex-col gap-4 p-5 rounded-2xl bg-slate-900/40 border border-slate-800">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 tracking-wide">
          <Home className="w-4 h-4 text-indigo-400" />
          <span>EXTERIOR COATING SYSTEM</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {PAINT_COLORS.map((col) => (
            <button
              key={col.name}
              id={`btn-color-${col.name.replace(/\s+/g, "-").toLowerCase()}`}
              onClick={() => updateControl("paintColor", col.name)}
              className={`flex items-center gap-2.5 p-2 rounded-xl border text-left transition-all duration-300 ${
                controls.paintColor === col.name
                  ? "bg-indigo-600/10 border-indigo-500/80 text-white shadow-md"
                  : "bg-slate-950/40 border-slate-800/80 text-slate-400 hover:text-slate-200 hover:border-slate-700"
              }`}
            >
              <span
                className="w-4 h-4 rounded-full border border-slate-700 shadow-inner flex-shrink-0"
                style={{ backgroundColor: col.hex }}
              />
              <div className="flex flex-col overflow-hidden">
                <span className="text-[10px] font-semibold leading-tight truncate">{col.name}</span>
                <span className="text-[8px] text-slate-500 font-mono truncate">{col.desc}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* SECTION 4: Amenities & Custom Installations */}
      <div className="flex flex-col gap-4 p-5 rounded-2xl bg-slate-900/40 border border-slate-800">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 tracking-wide">
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <span>FACILITIES & HARDWARE</span>
        </div>

        <div className="grid grid-cols-2 gap-x-4 gap-y-3">
          
          {/* Balcony */}
          <label className="flex items-center justify-between cursor-pointer group">
            <span className="text-xs text-slate-400 group-hover:text-slate-300 transition select-none">Cantilever Balcony</span>
            <input
              id="switch-balcony"
              type="checkbox"
              checked={controls.balcony}
              onChange={(e) => updateControl("balcony", e.target.checked)}
              className="w-8 h-4 rounded-full appearance-none bg-slate-800 checked:bg-indigo-500 relative cursor-pointer before:content-[''] before:absolute before:w-3.5 before:h-3.5 before:rounded-full before:bg-slate-300 before:top-[1px] before:left-[1px] checked:before:left-[15px] before:transition-all before:duration-300"
            />
          </label>

          {/* Garage */}
          <label className="flex items-center justify-between cursor-pointer group">
            <span className="text-xs text-slate-400 group-hover:text-slate-300 transition select-none">Glass Garage</span>
            <input
              id="switch-garage"
              type="checkbox"
              checked={controls.garage}
              onChange={(e) => updateControl("garage", e.target.checked)}
              className="w-8 h-4 rounded-full appearance-none bg-slate-800 checked:bg-indigo-500 relative cursor-pointer before:content-[''] before:absolute before:w-3.5 before:h-3.5 before:rounded-full before:bg-slate-300 before:top-[1px] before:left-[1px] checked:before:left-[15px] before:transition-all before:duration-300"
            />
          </label>

          {/* Garden */}
          <label className="flex items-center justify-between cursor-pointer group">
            <span className="text-xs text-slate-400 group-hover:text-slate-300 transition select-none">Minimalist Garden</span>
            <input
              id="switch-garden"
              type="checkbox"
              checked={controls.garden}
              onChange={(e) => updateControl("garden", e.target.checked)}
              className="w-8 h-4 rounded-full appearance-none bg-slate-800 checked:bg-indigo-500 relative cursor-pointer before:content-[''] before:absolute before:w-3.5 before:h-3.5 before:rounded-full before:bg-slate-300 before:top-[1px] before:left-[1px] checked:before:left-[15px] before:transition-all before:duration-300"
            />
          </label>

          {/* Swimming Pool */}
          <label className="flex items-center justify-between cursor-pointer group">
            <span className="text-xs text-slate-400 group-hover:text-slate-300 transition select-none">Infinity Pool</span>
            <input
              id="switch-pool"
              type="checkbox"
              checked={controls.swimmingPool}
              onChange={(e) => updateControl("swimmingPool", e.target.checked)}
              className="w-8 h-4 rounded-full appearance-none bg-slate-800 checked:bg-indigo-500 relative cursor-pointer before:content-[''] before:absolute before:w-3.5 before:h-3.5 before:rounded-full before:bg-slate-300 before:top-[1px] before:left-[1px] checked:before:left-[15px] before:transition-all before:duration-300"
            />
          </label>

          {/* Solar Panels */}
          <label className="flex items-center justify-between cursor-pointer group">
            <span className="text-xs text-slate-400 group-hover:text-slate-300 transition select-none">Solar Panels</span>
            <input
              id="switch-solar"
              type="checkbox"
              checked={controls.solarPanels}
              onChange={(e) => updateControl("solarPanels", e.target.checked)}
              className="w-8 h-4 rounded-full appearance-none bg-slate-800 checked:bg-indigo-500 relative cursor-pointer before:content-[''] before:absolute before:w-3.5 before:h-3.5 before:rounded-full before:bg-slate-300 before:top-[1px] before:left-[1px] checked:before:left-[15px] before:transition-all before:duration-300"
            />
          </label>

          {/* Smart Features */}
          <label className="flex items-center justify-between cursor-pointer group">
            <span className="text-xs text-slate-400 group-hover:text-slate-300 transition select-none">Smart LED Trims</span>
            <input
              id="switch-smart"
              type="checkbox"
              checked={controls.smartHomeFeatures}
              onChange={(e) => updateControl("smartHomeFeatures", e.target.checked)}
              className="w-8 h-4 rounded-full appearance-none bg-slate-800 checked:bg-indigo-500 relative cursor-pointer before:content-[''] before:absolute before:w-3.5 before:h-3.5 before:rounded-full before:bg-slate-300 before:top-[1px] before:left-[1px] checked:before:left-[15px] before:transition-all before:duration-300"
            />
          </label>

        </div>
      </div>

    </div>
  );
}
