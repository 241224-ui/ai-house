export interface RedesignControls {
  modernLevel: number;       // 1 - 100
  luxuryLevel: number;       // 1 - 100
  roofStyle: 'Flat Minimal' | 'Sloped Modern' | 'Glass Canopy';
  windowSize: 'Floor-to-Ceiling' | 'Panoramic' | 'Standard Minimal';
  wallMaterial: 'Concrete & Wood' | 'Stone & Glass' | 'Smooth White Stucco';
  paintColor: string;        // hex or name
  balcony: boolean;
  garage: boolean;
  garden: boolean;
  swimmingPool: boolean;
  solarPanels: boolean;
  smartHomeFeatures: boolean;
}

export interface HouseTemplate {
  id: string;
  name: string;
  style: string;
  originalUrl: string;
  redesignedUrl: string;
  description: string;
  defaultControls: RedesignControls;
}

export type LoadingStep = 
  | 'idle'
  | 'uploading'
  | 'analyzing'
  | 'generating'
  | 'rendering'
  | 'completed';
